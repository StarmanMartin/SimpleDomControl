import {} from "./controller/sdc_logout/sdc_logout.js";
import {} from "./controller/sdc_login/sdc_login.js";
