from django.apps import AppConfig
class SdcUserConfig(AppConfig):
    name = 'sdc_user'

