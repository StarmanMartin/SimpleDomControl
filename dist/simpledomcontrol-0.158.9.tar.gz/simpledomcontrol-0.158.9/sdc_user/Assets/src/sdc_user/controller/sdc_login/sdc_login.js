import {AbstractSDC, app, trigger, socketReconnect} from 'sdc_client';

class SdcLoginController extends AbstractSDC {

    constructor() {
        super();
        this.contentUrl = "/sdc_view/sdc_user/sdc_login"; //<sdc-login></sdc-login>
        this.contentReload = true;

        /**
         * Events is an array of dom events.
         * The pattern is {'event': {'dom_selector': handler}}
         * Uncommend the following line to add events;
         */
        // this.events.unshift({'click': {'.header-sample': (ev, $elem)=> $elem.css('border', '2px solid black')}}});
    }

    //-------------------------------------------------//
    // Lifecycle handler                               //
    // - onLoad (DOM not set)                          //
    // - willShow  (DOM set)                           //
    // - onRefresh  (recalled on reload)              //
    //-------------------------------------------------//
    // - onRemove                                      //
    //-------------------------------------------------//

    onLoad($html) {
        return super.onLoad($html);
    }

    willShow() {
        return super.willShow();
    }

    onRefresh() {
        return super.onRefresh();
    }

    onSubmit(serverRes) {
         if(serverRes.status ==="redirect" ) {
           location.assign(serverRes.url);
         } else {
            trigger('login');
         }
    }

}

app.register(SdcLoginController).addMixin('sdc-auto-submit');