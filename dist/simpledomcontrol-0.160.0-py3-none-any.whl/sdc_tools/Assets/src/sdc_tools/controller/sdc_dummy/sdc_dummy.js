import {AbstractSDC, app} from 'sdc_client';


/**
 * Placeholder/test view that shows the text of its `text` argument (e.g. `/~sdc-dummy~&text=Hello`) followed by any content placed inside the tag. Has no actions.
 */
class SdcDummyController extends AbstractSDC {

    constructor() {
        super();
        this.contentUrl = "/sdc_view/sdc_tools/sdc_dummy"; //<sdc-dummy></sdc-dummy>

        /**
         * Events is an array of dom events.
         * The pattern is {'event': {'dom_selector': handler}}
         * Uncommend the following line to add events;
         */
        // this.events.unshift({'click': {'.header-sample': (ev, $elem)=> $elem.css('border', '2px solid black')}}});
    }

    //-------------------------------------------------//
    // Lifecycle handler                               //
    // - onLoad (DOM not set)                          //
    // - willShow  (DOM set)                           //
    // - onRefresh  (recalled on reload)              //
    //-------------------------------------------------//
    // - onRemove                                      //
    //-------------------------------------------------//

    onInitDummy({ text }) {
        this._text = text;
    }

    onLoad($html) {
        this.onInitDummy(this.params);
        $html.find('.origen_content').append(this.$container.html());
        return super.onLoad($html);
    }

    willShow() {
        return super.willShow();
    }

    onRefresh() {
        return super.onRefresh();
    }

    page_text() {
        return <p className="col">{this._text || ''}</p>;
    }

}

app.register(SdcDummyController);