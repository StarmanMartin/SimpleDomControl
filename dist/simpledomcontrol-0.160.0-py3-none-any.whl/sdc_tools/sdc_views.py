from django.http import HttpResponse
from django.shortcuts import render

from django.conf import settings
from sdc_core.sdc_extentions.views import SDCView




class SdcNavigator(SDCView):
    template_name = 'sdc_tools/sdc/sdc_navigator.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)


class SdcListView(SDCView):
    template_name='sdc_tools/sdc/sdc_list_view.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcModelForm(SDCView):
    template_name='sdc_tools/sdc/sdc_model_form.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcDetailView(SDCView):
    template_name='sdc_tools/sdc/sdc_detail_view.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcSearchView(SDCView):
    template_name='sdc_tools/sdc/sdc_search_view.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcAlertMessenger(SDCView):
    template_name='sdc_tools/sdc/sdc_alert_messenger.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcError(SDCView):
    template_name='sdc_tools/sdc/sdc_error.html'

    def get_content(self, request, code, *args, **kwargs):
        return render(request, self.template_name, {'code': code})

class SdcDummy(SDCView):
    template_name='sdc_tools/sdc/sdc_dummy.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcSearchSelect(SDCView):
    template_name='sdc_tools/sdc/sdc_search_select.html'

    def get_content(self, request, *args, **kwargs):
        return render(request, self.template_name)

class SdcAiAssistant(SDCView):
    template_name='sdc_tools/sdc/sdc_ai_assistant.html'

    def get_content(self, request, *args, **kwargs):
        # Projects created before the AI settings existed have no SDC_AI_ASSISTANT: the assistant stays off
        enabled = getattr(settings, 'SDC_AI_ASSISTANT', False)
        if not enabled:
            return HttpResponse("", content_type="text/html")
        return render(request, self.template_name, {'SDC_AI_ASSISTANT': enabled})