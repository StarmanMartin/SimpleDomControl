poetry install --no-root
poetry add SimpleDomControl
yarn install

poetry run ./manage.py sdc_update_links