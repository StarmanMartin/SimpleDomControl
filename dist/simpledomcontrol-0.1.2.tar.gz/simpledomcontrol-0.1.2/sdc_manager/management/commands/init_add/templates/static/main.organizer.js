import {} from "./sdc_tools/js/sdc_tools.organizer.js"
//import {} from "./sdc_user/js/sdc_user.organizer.js"
import {app} from './simpleDomControl/sdc_main.js';


app.init_sdc();