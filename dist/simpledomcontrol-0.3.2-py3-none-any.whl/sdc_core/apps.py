from django.apps import AppConfig


class SdcManagerConfig(AppConfig):
    name = 'sdc_core'
