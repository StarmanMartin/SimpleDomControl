from django.apps import AppConfig


class SdcUserConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sdc_user"
