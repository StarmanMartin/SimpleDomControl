import {} from "./controller/sdc_reset_password/sdc_reset_password.js";
import {} from "./controller/sdc_password_forgotten/sdc_password_forgotten.js";
import {} from "./controller/sdc_change_password/sdc_change_password.js";
import {} from "./controller/sdc_user/sdc_user.js";
import {} from "./controller/sdc_confirm_email/sdc_confirm_email.js";
import {} from "./controller/sdc_user_nav_btn/sdc_user_nav_btn.js";
import {} from "./controller/sdc_logout/sdc_logout.js";
import {} from "./controller/sdc_login/sdc_login.js";