from django.apps import AppConfig


class SdcToolsConfig(AppConfig):
    name = 'sdc_tools'
