from sdc_tools.django_extension.views import SDCView
from django.shortcuts import render

